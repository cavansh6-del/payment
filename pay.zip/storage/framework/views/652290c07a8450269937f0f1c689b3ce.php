<div class="container mt-4">
    <h1 class="mb-4 mt-6">Order Payment Details</h1>

    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary">
            <h2>Order Information</h2>
        </div>
        <div class="card-body">
            <p><strong>Order ID:</strong> <?php echo e($order->id); ?></p>
            <p><strong>Order Total Amount:</strong> $<?php echo e(number_format($order->total_amount, 2)); ?></p>
            <p><strong>Order Status:</strong> <?php echo e($order->status); ?></p>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-header bg-info text-white">
            <h2>Payment Information</h2>
        </div>
        <div class="card-body">
            <!--[if BLOCK]><![endif]--><?php if($orderPayment): ?>
                <p><strong>Payer Name:</strong> <?php echo e($orderPayment->payer_name); ?></p>
                <p><strong>Bank Info:</strong> <?php echo e($orderPayment->payer_bank_info); ?></p>
                <p><strong>Payment Receipt:</strong>
                    <a href="<?php echo e(Storage::url($orderPayment->receipt_path)); ?>" class="btn btn-success" target="_blank">
                        <img src="<?php echo e(Storage::url($orderPayment->receipt_path)); ?>" />
                    </a>
                </p>
            <?php else: ?>
                <p>No payment information found for this order.</p>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <div class="d-flex justify-content-between">

        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['wire:click' => 'updateOrderStatus(\'completed\')','class' => 'mt-4','color' => 'gray']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'updateOrderStatus(\'completed\')','class' => 'mt-4','color' => 'gray']); ?>
            Confirm Order
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['wire:click' => 'updateOrderStatus(\'cancelled\')','class' => 'mt-4','color' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'updateOrderStatus(\'cancelled\')','class' => 'mt-4','color' => 'danger']); ?>
            Reject Order
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
        <!-- دکمه تایید سفارش -->

    </div>
</div>
<?php /**PATH C:\wamp64\www\paypal\resources\views/filament/pages/order-payment.blade.php ENDPATH**/ ?>