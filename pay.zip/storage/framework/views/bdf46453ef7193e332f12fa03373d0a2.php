<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <title>2E Bulk Order</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/main.jsx']); ?>
</head>
<body>
<div id="app"></div>
</body>
</html>
<?php /**PATH /home/paymentacc/domains/paymentacc.com/resources/views/app.blade.php ENDPATH**/ ?>